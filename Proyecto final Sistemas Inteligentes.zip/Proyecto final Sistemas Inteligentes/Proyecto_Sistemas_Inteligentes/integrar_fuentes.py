"""Cruce de fuentes a nivel municipio-mes, manteniendo la variable objetivo y la procedencia.

Fuentes: registros de Aerocivil, visitantes extranjeros no residentes,
calendarios de festividades y oferta turística del RNT. Los indicadores
representan poblaciones diferentes y sus conteos no deben sumarse.
"""
from pathlib import Path
import unicodedata
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATOS = ROOT / 'datos'
SALIDAS = ROOT / 'resultados_choco'
SALIDAS.mkdir(exist_ok=True)
KEY = ['municipio','anio','mes_num']

def normalizar(v):
    t = ''.join(ch for ch in unicodedata.normalize('NFKD',str(v).strip().upper()) if not unicodedata.combining(ch))
    return ' '.join(t.split())

def verificar(df, nombre, cols):
    faltan = set(cols) - set(df.columns)
    if faltan:raise ValueError(f'{nombre}: faltan columnas: {sorted(faltan)}')
    rep = df.duplicated(cols,keep=False)
    if rep.any():raise ValueError(f'{nombre}: {rep.sum()} claves repetidas en {cols}')

def main():
    air = pd.read_csv(DATOS/'aerocivil_municipal_recalculado.csv')
    ext = pd.read_csv(DATOS/'visitantes_extranjeros_municipal_mensual.csv')
    detail = pd.read_csv(DATOS/'visitantes_extranjeros_detalle.csv')
    rnt = pd.read_csv(DATOS/'oferta_rnt_corte_publicado.csv')
    cal = pd.read_csv(DATOS/'festividades_mensual.csv')

    for df in [air,ext,cal,rnt]:df['municipio']=df['municipio'].map(normalizar)
    # Equivalencia territorial explicita, no correccion silenciosa:
    rnt['municipio'] = rnt['municipio'].replace({'BAJO BAUDO (PIZARRO)':'BAJO BAUDO'})
    verificar(air,'Aerocivil',KEY)
    verificar(ext,'Extranjeros',KEY)
    verificar(cal,'Calendario',KEY)
    verificar(rnt,'RNT',['municipio'])

    # Variable extranjera: cobertura de la fuente externa; NaN=no reportado (NO 0).
    ext = ext.rename(columns={'visitantes':'extranjeros_no_residentes_registrados'}).drop(columns=['fecha'],errors='ignore')
    meses = {'ENE':1,'FEB':2,'MAR':3,'ABR':4,'MAY':5,'JUN':6,'JUL':7,'AGO':8,'SEP':9,'OCT':10,'NOV':11,'DIC':12}
    detail['municipio'] = detail['municipio_estandar'].map(normalizar)
    detail['anio']=detail['a_o']
    detail['mes_num']=detail['mes'].str.upper().str[:3].map(meses)
    if detail['mes_num'].isna().any():raise ValueError('Mes abreviado no reconocido en detalle de extranjeros.')
    paises=(detail.groupby(KEY,as_index=False).agg(paises_residencia_registrados=('pais_estandar','nunique'),conteo_detalle=('visitantes','sum')))
    verif=ext.merge(paises,on=KEY,how='outer',validate='one_to_one',indicator=True)
    if (verif['_merge']!='both').any() or (verif['extranjeros_no_residentes_registrados']!=verif['conteo_detalle']).any():
        raise ValueError('La serie extranjera no coincide con los registros detallados del propio proyecto.')
    ext = ext.merge(paises[KEY+['paises_residencia_registrados']],on=KEY,how='left',validate='one_to_one')

    dataset = air.merge(cal,on=KEY,how='left',validate='one_to_one',indicator='_cruce_calendario')
    if (dataset['_cruce_calendario']!='both').any():raise ValueError('Hay fechas Aerocivil sin calendario disponible.')
    dataset=dataset.drop(columns='_cruce_calendario')
    dataset=dataset.merge(ext,on=KEY,how='left',validate='one_to_one',indicator='_cruce_extranjeros')
    dataset['registro_extranjeros_disponible']=(dataset['_cruce_extranjeros']=='both')
    dataset=dataset.drop(columns='_cruce_extranjeros')
    rnt=rnt.rename(columns={'prestadores':'rnt_prestadores','camas':'rnt_camas','habitaciones':'rnt_habitaciones','empleados':'rnt_empleados'})
    dataset=dataset.merge(rnt,on='municipio',how='left',validate='many_to_one',indicator='_cruce_rnt')
    dataset['corte_rnt_disponible']=(dataset['_cruce_rnt']=='both')
    dataset=dataset.drop(columns='_cruce_rnt')
    dataset['fecha']=pd.to_datetime(dict(year=dataset.anio,month=dataset.mes_num,day=1)).dt.strftime('%Y-%m-%d')
    dataset=dataset.sort_values(KEY).reset_index(drop=True)
    assert len(dataset)==len(air)==494
    assert dataset['llegadas'].sum()==air['llegadas'].sum()
    assert dataset['salidas'].sum()==air['salidas'].sum()
    assert dataset['extranjeros_no_residentes_registrados'].notna().sum()==310
    assert dataset['registro_extranjeros_disponible'].eq(dataset['extranjeros_no_residentes_registrados'].notna()).all()
    # Nunca convertir extranjeros o RNT en parte del conteo de llegadas.
    dataset.to_csv(DATOS/'dataset_integrado_multifuente.csv',index=False,encoding='utf-8-sig')

    cobertura=dataset.groupby('municipio',as_index=False).agg(
        meses_aerocivil=('fecha','size'),
        meses_con_extranjeros=('registro_extranjeros_disponible','sum'),
        tiene_rnt=('corte_rnt_disponible','max'),
        llegadas_aereas_registradas=('llegadas','sum'),
        extranjeros_en_meses_coincidentes=('extranjeros_no_residentes_registrados','sum')
    )
    cobertura.to_csv(SALIDAS/'cobertura_integracion_fuentes.csv',index=False,encoding='utf-8-sig')
    byyear=dataset.groupby('anio',as_index=False).agg(
        observaciones_aerocivil=('fecha','size'),
        observaciones_extranjeros_disponibles=('registro_extranjeros_disponible','sum'),
        llegadas_aereas=('llegadas','sum'),
        extranjeros_meses_coincidentes=('extranjeros_no_residentes_registrados','sum')
    )
    byyear['estado_anio'] = byyear['anio'].map(lambda x:'Parcial: enero-junio' if x==2026 else 'Año calendario')
    byyear.to_csv(SALIDAS/'resumen_anual_integracion_fuentes.csv',index=False,encoding='utf-8-sig')

    # Comparacion de tendencias: paneles distintos, NO sumar ni transformar en turismo total.
    h=dataset[dataset.anio<=2025].copy()
    serie=h.groupby('fecha').agg(llegadas=('llegadas','sum'),extranjeros=('extranjeros_no_residentes_registrados',lambda s:s.sum(min_count=1)),n=('registro_extranjeros_disponible','sum')).reset_index()
    serie['fecha']=pd.to_datetime(serie['fecha'])
    serie.loc[serie.n.eq(0),'extranjeros']=np.nan
    fig,(a,b)=plt.subplots(2,1,figsize=(12,6.7),sharex=True,constrained_layout=True)
    a.plot(serie.fecha,serie.llegadas,lw=1.8,color='#277659');a.set_title('Llegadas aéreas registradas (Aerocivil, siete municipios)',loc='left',fontweight='bold');a.set_ylabel('Pasajeros');a.grid(alpha=.2)
    b.plot(serie.fecha,serie.extranjeros,lw=1.8,color='#bd7a30');b.set_title('Visitantes extranjeros no residentes (solo registros coincidentes)',loc='left',fontweight='bold');b.set_ylabel('Visitantes registrados');b.grid(alpha=.2)
    b.set_xlabel('Mes');fig.suptitle('Fuentes complementarias: indicadores distintos, no se suman',fontsize=14,fontweight='bold')
    fig.savefig(SALIDAS/'06_tendencias_fuentes_integradas.png',dpi=175,bbox_inches='tight');plt.close(fig)

    data2025=dataset[dataset.anio.eq(2025)].groupby('municipio',as_index=False)['llegadas'].sum()
    rnt7=rnt.merge(data2025,on='municipio',how='inner',validate='one_to_one').sort_values('llegadas')
    fig,(a,b)=plt.subplots(1,2,figsize=(13,5.5),constrained_layout=True)
    a.barh(rnt7.municipio,rnt7.llegadas,color='#277659');a.set_title('Llegadas aéreas (2025)');a.set_xlabel('Pasajeros registrados');a.grid(axis='x',alpha=.2)
    b.barh(rnt7.municipio,rnt7.rnt_prestadores,color='#b88c38');b.set_title('Prestadores turísticos (RNT, corte publicado)');b.set_xlabel('Número de prestadores');b.grid(axis='x',alpha=.2)
    fig.suptitle('Movilidad y oferta turística: variables de distinta naturaleza',fontweight='bold',fontsize=14)
    fig.savefig(SALIDAS/'07_movilidad_oferta_rnt.png',dpi=175,bbox_inches='tight');plt.close(fig)
    print('Integración verificada:',len(dataset),'filas.',int(dataset.registro_extranjeros_disponible.sum()),'filas con conteo extranjero;', int(dataset.corte_rnt_disponible.sum()),'filas con RNT.')
    return dataset, cobertura, byyear

if __name__=='__main__':main()
