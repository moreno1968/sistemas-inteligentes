# Síntesis para sustentación

**Problema:** la actividad turística del Chocó se documenta en fuentes separadas, lo que dificulta reconocer patrones conjuntos y prever períodos de mayor demanda.

**Solución:** se vincularon Aerocivil, visitantes extranjeros y RNT por municipio y período, y se añadió información de festividades. Se compararon métodos históricos con Random Forest usando validación temporal.

**Resultado:** el análisis integrado permite estudiar territorios y temporadas. Para predecir se utiliza la serie mensual de llegadas aéreas; Random Forest clasifica la demanda y un método estacional suavizado ofrece una segunda referencia de cantidades.

**Evidencia:** 494 observaciones, siete municipios y 126 pronósticos. El error WAPE en 2025 fue 10,29 % para la referencia suavizada y 12,75 % para Random Forest con festividades. En el primer semestre de 2026 fue 8,15 % y 7,85 %, respectivamente.

**Interpretación:** el modelo apoya la planificación turística al anticipar meses de mayor actividad. Las cifras de pasajeros no equivalen al número total de turistas.
