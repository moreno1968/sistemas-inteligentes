"""Evaluación reproducible de una referencia estacional de dos años.

No infiere turistas totales: se pronostican pasajeros aéreos de los municipios
con cobertura Aerocivil y se usa el resto de las fuentes como contexto de turismo.
Peso de y-2: elegido SOLO con validación 2024; años 2025 y 2026 intocados.
"""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import modelo_afluencia as mod

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'resultados'
IMAGES=ROOT/'resultados_choco'
MUNI=ROOT/'resultados_municipales'
for d in (OUT, IMAGES, MUNI):d.mkdir(exist_ok=True)


def smooth_pred(train,test,weight,lag1=None):
    index=train.set_index(['municipio','anio','mes_num']).llegadas
    lag1=mod.last_year_baseline(train,test) if lag1 is None else np.asarray(lag1,dtype=float)
    lag2=np.array([index.get((r.municipio,int(r.anio)-2,int(r.mes_num)),np.nan) for r in test.itertuples()],dtype=float)
    lag2=np.where(np.isfinite(lag2),lag2,lag1)  # ausencia no equivale a 0
    return np.maximum(0,(1-weight)*lag1+weight*lag2)


def compare():
    air=mod.load_observed().sort_values(['anio','mes_num','municipio'])
    assert not air.duplicated(['municipio','anio','mes_num']).any()
    train2024=air[air.anio<=2023].copy()
    val2024=air[air.anio==2024].copy()
    candidates=[]
    for weight in np.round(np.arange(0,0.51,.05),2):
        preds=smooth_pred(train2024,val2024,float(weight))
        candidates.append({'peso_segundo_anio':float(weight),'WAPE_validacion_2024':float(mod.wape(val2024.llegadas,preds))})
    search=pd.DataFrame(candidates)
    search.to_csv(OUT/'ajuste_suavizado_2024.csv',index=False,encoding='utf-8-sig')
    best=float(search.sort_values(['WAPE_validacion_2024','peso_segundo_anio']).iloc[0].peso_segundo_anio)
    rows=[];detail=[]
    for year,monthmax,name in [(2024,12,'Validación 2024'),(2025,12,'Prueba 2025'),(2026,6,'Seguimiento 2026 (ene-jun)')]:
        tr=air[air.anio<year].copy()
        te=air[(air.anio==year)&(air.mes_num<=monthmax)].copy()
        pred=smooth_pred(tr,te,best)
        metric,items=mod.eval_model(tr,te,pred,'Referencia estacional suavizada',name)
        metric['peso_segundo_anio']=best
        metric['funcion']='Pronóstico mensual de llegadas aéreas; no turistas totales'
        rows.append(metric);detail.append(items)
    metrics=pd.DataFrame(rows)
    metrics.to_csv(OUT/'evaluacion_referencia_suavizada.csv',index=False,encoding='utf-8-sig')
    pd.concat(detail,ignore_index=True).to_csv(OUT/'evaluacion_referencia_suavizada_detalle.csv',index=False,encoding='utf-8-sig')
    # Comparación imparcial a partir de las mismas observaciones y cortes.
    base=pd.read_csv(OUT/'comparacion_modelos_aerocivil.csv')
    merged=pd.concat([base,metrics.drop(columns=['peso_segundo_anio','funcion'])],ignore_index=True)
    merged.to_csv(OUT/'comparacion_modelos_con_suavizado.csv',index=False,encoding='utf-8-sig')
    test=merged[merged.division.isin(['Prueba 2025','Seguimiento 2026 (ene-jun)'])]
    names=['Mismo mes año previo','Referencia estacional suavizada','RF con festividades']
    widths=0.24
    fig,ax=plt.subplots(figsize=(10.4,5.1),layout='constrained')
    for idx,label in enumerate(names):
        s=test[test.modelo==label].set_index('division').reindex(['Prueba 2025','Seguimiento 2026 (ene-jun)']).WAPE_pct
        vals=s.to_numpy(float)
        pos=np.arange(2)+(idx-1)*widths
        bars=ax.bar(pos,vals,widths,label=label)
        ax.bar_label(bars,fmt='%.2f%%',padding=3,fontsize=9)
    ax.set_xticks([0,1],['Año 2025','2026 (enero–junio)'])
    ax.set_ylim(0,max(test[test.modelo.isin(names)].WAPE_pct)*1.22)
    ax.set_ylabel('Error WAPE (%) · menor es mejor')
    ax.set_title('Comparación temporal: la mejor opción cambia según el período',loc='left',weight='bold')
    ax.legend(loc='upper right',fontsize=9)
    ax.grid(axis='y',alpha=.17)
    fig.savefig(IMAGES/'09_prueba_modelos_estacional_suavizado.png',dpi=180,bbox_inches='tight')
    plt.close(fig)
    return best,metrics,merged


def forecast(best):
    air=mod.load_observed()
    # El método estacional solo usa valores anteriores conocidos o predicciones recursivas.
    known={(r.municipio,int(r.anio),int(r.mes_num)):float(r.llegadas) for r in air.itertuples()}
    count=air.groupby('municipio').llegadas.size()
    cuts=mod.thresholds_by_municipio(air)
    rec=[]
    months=[(2026,m) for m in range(7,13)]+[(2027,m) for m in range(1,13)]
    all_forecasts={}
    for year,month in months:
        for municipality in sorted(air.municipio.unique()):
            t1=(municipality,year-1,month);t2=(municipality,year-2,month)
            y1=known.get(t1,all_forecasts.get(t1))
            y2=known.get(t2,all_forecasts.get(t2))
            seasonal=air[(air.municipio==municipality)&(air.mes_num==month)].llegadas
            fallback=float(seasonal.median()) if len(seasonal) else float(air[air.municipio==municipality].llegadas.median())
            if y1 is None and y2 is None:estimate=fallback; method='Mediana histórica (sin mismos meses previos)'
            elif y1 is None:estimate=y2; method='Segundo año previo (primero ausente)'
            elif y2 is None:estimate=y1; method='Año anterior (segundo ausente)'
            else:
                estimate=(1-best)*y1+best*y2
                method='Recursivo: usa pronósticos anteriores' if t1 in all_forecasts or t2 in all_forecasts else 'Basado en observaciones previas'
            all_forecasts[municipality,year,month]=max(0,float(estimate))
            rec.append({'municipio':municipality,'anio':year,'mes_num':month,'estimacion_estacional':int(round(max(0,estimate))),
                        'demanda_estacional':mod.demand_label(municipality,float(estimate),cuts),'metodo_estacional':method,
                        'meses_historicos':int(count[municipality]),'riesgo_cobertura':'Alto: menos de 36 meses' if count[municipality]<36 else 'Revisión necesaria'})
    seasonal=pd.DataFrame(rec)
    rf=pd.read_csv(MUNI/'pronostico_llegadas_2026H2_2027.csv')
    assert not rf.duplicated(['municipio','anio','mes_num']).any()
    comparative=rf[['municipio','anio','mes_num','pred_llegadas','demanda_prevista']].merge(seasonal,on=['municipio','anio','mes_num'],how='outer',validate='one_to_one',indicator=True)
    assert (comparative._merge=='both').all()
    comparative=comparative.drop(columns=['_merge']).rename(columns={'pred_llegadas':'estimacion_random_forest','demanda_prevista':'demanda_random_forest'})
    comparative['diferencia_relativa_pct']=np.where(comparative.estimacion_estacional>0,
        (comparative.estimacion_random_forest-comparative.estimacion_estacional).abs()/comparative.estimacion_estacional*100,np.nan)
    comparative['coinciden_categorias']=comparative.demanda_estacional==comparative.demanda_random_forest
    comparative.to_csv(MUNI/'pronostico_comparativo_dos_modelos.csv',index=False,encoding='utf-8-sig')
    group=comparative.groupby(['anio','mes_num'],as_index=False).agg(
        estimacion_estacional=('estimacion_estacional','sum'),estimacion_rf=('estimacion_random_forest','sum'),
        municipios=('municipio','nunique'),coincidencias=('coinciden_categorias','sum'))
    group['advertencia']='Solo siete municipios con cobertura aérea, no todos los turistas'
    group.to_csv(OUT/'comparacion_mensual_2026H2_2027.csv',index=False,encoding='utf-8-sig')
    return comparative,group


def source_diagnostics():
    data=pd.read_csv(ROOT/'datos/dataset_integrado_multifuente.csv')
    air=pd.read_csv(ROOT/'datos/aerocivil_choco_mensual.csv')
    assert not data.duplicated(['municipio','anio','mes_num']).any()
    assert len(data)==len(air) and data.llegadas.sum()==air.llegadas.sum()
    assert data.extranjeros_no_residentes_registrados.notna().sum()==310
    diag={'filas_aerocivil':int(len(air)), 'filas_integradas':int(len(data)),
        'con_registro_extranjeros':int(data.extranjeros_no_residentes_registrados.notna().sum()),
        'sin_registro_extranjeros':int(data.extranjeros_no_residentes_registrados.isna().sum()),
        'municipios_aerocivil':int(data.municipio.nunique()),
        'rnt_sin_fecha_historica_verificable':True,
        'se_sumaron_pasajeros_y_extranjeros':False,
        'target':'pasajeros aéreos llegados, no turistas totales',
        'unidad_union':'municipio-anio-mes_num',
        'criterio_predictivo':'No usar conteo extranjero contemporáneo ni RNT sin fecha histórica como predictor de períodos futuros',
        'extranjeros_faltantes_no_igual_a_cero':True,
        '2026_parcial':'ene-jun para datos observados'}
    (OUT/'auditoria_integracion_y_modelo.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2),encoding='utf-8')
    return diag


def main():
    best,metrics,combined=compare()
    forecasts,group=forecast(best)
    diag=source_diagnostics()
    print('Peso y-2 elegido con 2024:',best,'\n',metrics[['division','WAPE_pct','MAE','acierto_demanda_pct']].round(3).to_string(index=False))
    print('Cobertura integración',diag,'\nPronósticos comparativos:',len(forecasts))
    return best,metrics,combined,forecasts,group,diag

if __name__=='__main__':main()
