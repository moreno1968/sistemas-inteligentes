# Evaluación del aporte de las fuentes integradas al modelo predictivo

**Proyecto:** Afluencia aérea mensual en municipios del Chocó.  
**Variable objetivo:** cantidad de pasajeros aéreos que llegan por municipio y mes, según los registros de Aerocivil disponibles en `datos/aerocivil_choco_raw.csv`. **No** equivale al total de turistas.  
**Conclusión:** mantener **Random Forest con festividades** como variante de aprendizaje automático del proyecto. Los perfiles históricos de extranjeros y el corte estático del RNT **no mejoraron de forma consistente** su error en la prueba de 2025. Conservar el **mismo mes del año anterior** como referencia de error de conteo.

## 1. Diseño de la evaluación

- Los **datos de Aerocivil** son la variable a predecir. No se suman con los registros de visitantes extranjeros.
- Se mantuvieron los **mismos registros** para todos los modelos: **84 para ajuste de hiperparámetros en 2024, 82 para prueba en 2025 y 40 para seguimiento en enero–junio de 2026**.
- Los parámetros de los cinco Random Forest se eligieron comparando tres configuraciones con datos anteriores a 2024 y validación en 2024. **2024 se utiliza para selección, no como evaluación independiente**.
- Para la prueba de 2025 se entrenó con registros de Aerocivil hasta 2024; para el seguimiento del primer semestre de 2026, se entrenó con registros hasta 2025. La información de los meses evaluados nunca se utilizó en el entrenamiento de ese mismo corte.
- Los perfiles de extranjeros se construyeron únicamente con **promedios históricos de municipio y municipio–mes de años anteriores al corte**. No se utiliza el número real de extranjeros del mes que se intenta predecir. Una falta de registro no se interpreta como cero.
- Las cifras RNT (prestadores, camas y habitaciones) son datos estáticos municipales de un **corte sin fecha histórica documentada**: se evaluaron solo como ejercicio exploratorio. No se puede demostrar que esos valores estuvieran disponibles en todos los años anteriores.
- El modelo incluye como variables de control municipio, mes, tendencia anual y, según el escenario, calendario de festividades. Las transformaciones y el Random Forest se ajustan únicamente al entrenamiento de cada corte.
- El indicador principal es **WAPE**, y se informan también el error absoluto medio (**MAE**) y el porcentaje de meses bien clasificados en demanda alta, media y baja. La clasificación utiliza umbrales definidos con los registros de entrenamiento.

## 2. Resultados cuantitativos

| Modelo | WAPE 2025 | Acierto demanda 2025 | WAPE 2026, ene–jun | Acierto demanda 2026, ene–jun |
|---|---:|---:|---:|---:|
| Mismo mes del año anterior | 10.51% | 60.98% | 8.45% | 67.50% |
| Mediana estacional | 15.32% | 46.34% | 11.63% | 40.00% |
| Random Forest sin festividades | 13.43% | 63.41% | 8.74% | 72.50% |
| Random Forest + festividades | 12.75% | 64.63% | 7.85% | 70.00% |
| RF + festividades + RNT | 12.81% | 62.20% | 7.78% | 70.00% |
| RF + festividades + extranjeros históricos | 12.97% | 62.20% | 8.28% | 65.00% |
| RF + festividades + RNT + extranjeros | 13.03% | 62.20% | 8.30% | 65.00% |

## 3. ¿Mejoran las nuevas variables?

**RNT.** El WAPE pasó de **12,75 % a 12,81 %** en 2025 al incorporarlo, por lo que empeoró ligeramente. En enero–junio de 2026 bajó de **7,85 % a 7,78 %**: mejora muy pequeña, no sostenida entre períodos y afectada por la falta de fecha histórica del RNT. **No justifica adoptarlo como predictor confirmado**.

**Extranjeros históricos.** Incorporar promedios por municipio y mes elevó el WAPE a **12,97 % en 2025** y **8,28 % en 2026**. La integración es válida para describir las fuentes y sus coberturas, pero este perfil no aportó mejora predictiva en estos períodos. Nunca se usó el conteo extranjero del mes futuro como predictor.

**Todas las variables.** El modelo combinado alcanzó **13,03 % en 2025 y 8,30 % en el primer semestre de 2026**, ambos peores que el RF únicamente con festividades.

**Método histórico.** El pronóstico de **mismo mes del año anterior** obtuvo el WAPE más bajo de 2025 (**10,51 %**), por delante de todas las variantes Random Forest. Para 2026 parcial, el RF con festividades fue mejor que la referencia histórica (7,85 % frente a 8,45 %). Por tanto, no se debe afirmar que RF domine todos los períodos.

**Demanda categórica.** En 2025, Random Forest con festividades obtuvo el mayor acierto entre los modelos evaluados (**64,63 %**). La mejor opción depende de qué objetivo se priorice: error de cantidad o clasificación de temporada.

## 4. Limitaciones y precauciones

1. El dataset abarca **siete municipios con registro aéreo**, no todas las formas de llegada al departamento. Un pasajero puede viajar por motivos distintos al turismo.
2. La cobertura es desigual y algunos municipios tienen pocos registros o volúmenes pequeños. Por ejemplo, los errores relativos municipales individuales de Bajo Baudó y Juradó son elevados: los WAPE agregados quedan dominados por municipios con mayor volumen de tráfico.
3. El seguimiento de **2026** solo incluye **enero–junio** y 40 registros, por lo que no equivale a una validación anual completa.
4. Los registros de visitantes extranjeros coinciden con **310 de 494** filas de Aerocivil. Los faltantes no se imputaron como ceros.
5. El RNT corresponde a un **corte publicado** y no a una historia mensual. Se requiere verificar la fecha de referencia antes de utilizarlo en validación retrospectiva estricta.
6. Estas comparaciones constituyen una **evaluación empírica limitada**, no una prueba causal de que las fiestas o la oferta turística determinen las llegadas.

## 5. Decisión documentada

**Se conserva el modelo activo Random Forest con festividades, sin incorporar nuevas columnas a la predicción actual**, porque ninguna de las variables adicionales demuestra mejoría repetida en la métrica principal. Las bases RNT y extranjeros permanecen integradas en el EDA para ofrecer contexto. Se conserva la referencia histórica del mismo mes del año anterior para no sobrestimar la calidad del modelo.

La evaluación es reproducible con:

```bash
python evaluar_variables_integradas.py
```

Genera `evaluacion_integrada_tuning_2024.csv`, `evaluacion_integrada_comparacion.csv`, `evaluacion_integrada_detalle.csv` y `evaluacion_integrada_municipios.csv` en `resultados/`.
