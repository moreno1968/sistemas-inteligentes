# Resumen ejecutivo: análisis de la actividad turística y predicción de un indicador mensual en el Chocó

## Propósito y alcance

El proyecto analiza **la actividad turística del Chocó** mediante la integración de movilidad aérea, registros de visitantes extranjeros no residentes, oferta turística del RNT y festividades. El EDA busca reconocer cambios temporales, diferencias municipales y limitaciones de cobertura. Para la fase predictiva se eligió una medida observable por municipio y mes: las **llegadas aéreas**, utilizadas como indicador indirecto de afluencia relacionada con el turismo. No se interpreta esta medida como el total de turistas del departamento.

La base principal de tráfico aéreo, identificada como información de Aerocivil, reúne **606 registros aeropuerto–mes**, que se agregaron en **494 registros municipio–mes**. La serie observada cubre de enero de 2020 a junio de 2026. En el cruce multifuente, 310 observaciones aéreas coinciden con registros de extranjeros y 184 no cuentan con coincidencia; no se sumaron esas cifras a las llegadas aéreas ni se separaron pasajeros por nacionalidad.

## Hallazgos del EDA

**Movilidad aérea (una de las dimensiones analizadas).** En los aeropuertos incluidos se registraron **253.547 llegadas en 2024** y **270.844 en 2025**, un incremento aproximado del **6,8 %**. Los **119.817 pasajeros de enero–junio de 2026** son un resultado semestral y no deben compararse directamente con los totales de años completos.

Durante 2025, **Quibdó** concentró **175.337 llegadas**, seguido de **Bahía Solano** (47.745) y **Nuquí** (39.583). La mediana mensual para 2021–2025 destaca julio, agosto y diciembre como meses de mayor actividad agregada. Se identificaron **52 combinaciones municipio–mes sin reporte**, que no se confundieron con meses de cero pasajeros. Juradó tiene la cobertura histórica más limitada. **La integración aporta otras dos dimensiones:** la serie de visitantes extranjeros permite contrastar cobertura y tendencias, mientras que el RNT describe oferta de prestadores y alojamiento. Ninguna representa el total departamental de turistas.

## Evaluación del modelo

Se compararon mediana estacional, mismo mes del año anterior, Random Forest sin festividades y Random Forest con festividades. Para evaluar los resultados se mantuvo una separación temporal entre entrenamiento y prueba.

En **2025**, el método **mismo mes del año anterior** obtuvo el menor error numérico (**WAPE de 10,51 %; MAE de 347,10 pasajeros**). Random Forest con festividades registró un **WAPE de 12,75 % y MAE de 421,24**, aunque alcanzó **64,63 % de acierto** al clasificar demanda alta, media o baja. Durante **enero–junio de 2026**, su WAPE fue **7,85 %**, frente al 8,45 % de la referencia del año anterior. Esta última comparación cubre únicamente un semestre.

## Pronóstico y conclusión

Con los datos observados hasta junio de 2026 se generaron **126 predicciones municipio–mes** para julio de 2026 a diciembre de 2027. La suma proyectada para 2027 es de aproximadamente **263.668 llegadas aéreas** en los aeropuertos incluidos. Las clasificaciones de demanda son relativas al historial de cada municipio, no una comparación directa de volumen entre territorios.

El aporte principal del trabajo consiste en integrar el análisis exploratorio, la comparación objetiva de modelos y la generación de pronósticos interpretables. Su aplicación es **exploratoria y académica**: las cifras futuras pueden variar por cambios operativos o territoriales y no deben presentarse como una estimación oficial de todos los turistas del Chocó.
