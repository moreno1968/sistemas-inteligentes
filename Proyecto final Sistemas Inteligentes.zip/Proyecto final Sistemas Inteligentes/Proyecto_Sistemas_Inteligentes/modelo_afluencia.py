"""Análisis reproducible de llegadas aéreas mensuales al Chocó.

Datos de tráfico aéreo de Aerocivil incluidos en el repositorio. La unidad es PASAJEROS AÉREOS,
no turistas identificados ni llegadas al departamento por todos los medios.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import json
import sys
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'datos'
RESULTS = ROOT / 'resultados'
MUNI = ROOT / 'resultados_municipales'
MODEL_OUT = ROOT / 'resultados_predictivo'
MONTH_NAMES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
AIRPORT_TO_MUNI = {
    'ACD': 'ACANDI', 'CPB': 'ACANDI',
    'BSC': 'BAHIA SOLANO', 'CPC': 'BAHIA SOLANO',
    'BBA': 'BAJO BAUDO', 'COG': 'CONDOTO', 'JUR': 'JURADO',
    'NQU': 'NUQUI', 'UIB': 'QUIBDO',
}
EVENT_FEATURES = ['dias_fiesta','dias_ballenas','dias_festivo_nac','puentes','semana_santa_dias']
BASIC_FEATURES = ['municipio','mes_num','mes_sin','mes_cos','anio']
CONFIGS = [
    {'n_estimators': 160, 'min_samples_leaf': 2, 'max_features': 0.8},
    {'n_estimators': 160, 'min_samples_leaf': 4, 'max_features': 0.8},
    {'n_estimators': 240, 'min_samples_leaf': 3, 'max_features': 1.0},
]


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding='utf-8-sig')


def load_observed() -> pd.DataFrame:
    """Agrupa registros por aeropuerto sin imputar meses faltantes como ceros."""
    df = pd.read_csv(DATA / 'aerocivil_choco_raw.csv')
    required = {'anio','mes','aeropuerto','llegadas','salidas'}
    if set(df) != required:
        raise ValueError(f'Estructura de Aerocivil inesperada: {set(df)^required}')
    if df.duplicated(['anio','mes','aeropuerto']).any():
        raise ValueError('Registros duplicados por aeropuerto-mes: revisar el origen.')
    unknown = set(df.aeropuerto)-set(AIRPORT_TO_MUNI)
    if unknown:
        raise ValueError(f'Códigos de aeropuerto sin asignar: {unknown}')
    if not df.anio.between(2020,2100).all() or not df.mes.between(1,12).all():
        raise ValueError('Año o mes inválido.')
    for col in ('llegadas','salidas'):
        if (df[col] < 0).any() or df[col].isna().any():
            raise ValueError(f'Valor inválido en {col}.')
    df['municipio']=df.aeropuerto.map(AIRPORT_TO_MUNI)
    result=(df.groupby(['municipio','anio','mes'],as_index=False)[['llegadas','salidas']].sum()
              .rename(columns={'mes':'mes_num'})
              .sort_values(['municipio','anio','mes_num']).reset_index(drop=True))
    result['fecha']=pd.to_datetime(dict(year=result.anio,month=result.mes_num,day=1))
    assert int(result.llegadas.sum())==int(df.llegadas.sum()), 'No se conservó el total.'
    return result


def load_calendar() -> pd.DataFrame:
    f=pd.read_csv(DATA / 'festividades_mensual.csv')
    required={'municipio','anio','mes_num'}|set(EVENT_FEATURES)
    if not required.issubset(f.columns):
        raise ValueError('El calendario de festividades tiene columnas faltantes.')
    if f.duplicated(['municipio','anio','mes_num']).any():
        raise ValueError('Festividades duplicadas por municipio-mes.')
    if f[list(EVENT_FEATURES)].isna().any().any():
        raise ValueError('Festividades con valores nulos.')
    if (f[list(EVENT_FEATURES)]<0).any().any():
        raise ValueError('Festividades con días negativos.')
    return f[list(['municipio','anio','mes_num']+EVENT_FEATURES)]


def join_events(data: pd.DataFrame) -> pd.DataFrame:
    full=data.merge(load_calendar(),on=['municipio','anio','mes_num'],how='left',validate='many_to_one',indicator=True)
    if not (full._merge=='both').all():
        missing=full.loc[full._merge!='both',['municipio','anio','mes_num']].to_dict('records')[:8]
        raise ValueError(f'Sin calendario para {missing}. No se rellenarán eventos automáticamente.')
    return full.drop(columns='_merge')


def add_features(df: pd.DataFrame, include_events: bool) -> pd.DataFrame:
    x=df.copy()
    x['mes_sin']=np.sin(2*np.pi*x.mes_num/12)
    x['mes_cos']=np.cos(2*np.pi*x.mes_num/12)
    keep=BASIC_FEATURES+(EVENT_FEATURES if include_events else [])
    return x[keep]


def fit_rf(train: pd.DataFrame, include_events=True, config=None) -> Pipeline:
    settings=config or CONFIGS[0]
    cols=['mes_sin','mes_cos','anio']+(EVENT_FEATURES if include_events else [])
    prep=ColumnTransformer([
        ('municipio', OneHotEncoder(handle_unknown='ignore'), ['municipio']),
        ('mes', OneHotEncoder(handle_unknown='ignore'), ['mes_num']),
        ('continuas','passthrough',cols),
    ])
    rf=RandomForestRegressor(**settings,random_state=42,n_jobs=-1)
    model=Pipeline([('preprocesamiento',prep),('random_forest',rf)])
    model.fit(add_features(train,include_events),np.log1p(train.llegadas))
    return model


def rf_predictions(model: Pipeline, frame: pd.DataFrame, include_events=True) -> np.ndarray:
    return np.maximum(0,np.expm1(model.predict(add_features(frame,include_events))))


def median_baseline(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    season=train.groupby(['municipio','mes_num']).llegadas.median()
    municipal=train.groupby('municipio').llegadas.median()
    return np.array([float(season.get((r.municipio,r.mes_num),municipal.get(r.municipio,np.nan))) for r in test.itertuples()])


def last_year_baseline(train:pd.DataFrame, test:pd.DataFrame) -> np.ndarray:
    key=train.set_index(['municipio','anio','mes_num']).llegadas
    fallback=median_baseline(train,test)
    return np.array([
        float(key.get((r.municipio,r.anio-1,r.mes_num),fallback[i]))
        for i,r in enumerate(test.itertuples())
    ])


def wape(actual,pred):
    actual=np.asarray(actual,float);pred=np.asarray(pred,float)
    denominator=actual.sum()
    return 100.0*np.sum(np.abs(actual-pred))/denominator if denominator>0 else np.nan


def thresholds_by_municipio(train):
    recent=train[(train.anio>=max(2020,int(train.anio.max())-2))]
    cuts={}
    for muni,g in recent.groupby('municipio'):
        if len(g)>=9 and g.llegadas.nunique()>=3:
            low,high=np.quantile(g.llegadas,[1/3,2/3])
            if low<high:cuts[muni]=(float(low),float(high))
    return cuts


def demand_label(municipio,estimate,cuts):
    if municipio not in cuts or not np.isfinite(estimate):return 'No estimable'
    low,high=cuts[municipio]
    if estimate<=low:return 'Baja'
    if estimate<=high:return 'Media'
    return 'Alta'


def eval_model(train,test,pred,model_name,split):
    y=test.llegadas.to_numpy(dtype=float)
    cuts=thresholds_by_municipio(train)
    true_labels=[demand_label(r.municipio,r.llegadas,cuts) for r in test.itertuples()]
    pred_labels=[demand_label(r.municipio,float(pred[i]),cuts) for i,r in enumerate(test.itertuples())]
    valid=np.array([x!='No estimable' for x in true_labels])
    accuracy=(np.mean(np.array(true_labels)[valid]==np.array(pred_labels)[valid])*100 if valid.sum() else np.nan)
    result={'division':split,'modelo':model_name,'n':len(test),'MAE':float(mean_absolute_error(y,pred)),
            'WAPE_pct':float(wape(y,pred)),'acierto_demanda_pct':float(accuracy),'n_clasificables':int(valid.sum())}
    details=test[['municipio','anio','mes_num','llegadas']].copy()
    details['modelo']=model_name;details['division']=split;details['pred_llegadas']=np.round(pred,2)
    details['error_abs']=np.round(np.abs(y-pred),2)
    details['demanda_observada']=true_labels;details['demanda_prevista']=pred_labels
    return result,details


def choose_config(data,include_events):
    """Búsqueda acotada SOLO con validación 2024; 2025/2026 no participan."""
    tr=data[data.anio<=2023].copy()
    va=data[data.anio==2024].copy()
    choices=[]
    for conf in CONFIGS:
        model=fit_rf(tr,include_events,conf)
        pred=rf_predictions(model,va,include_events)
        choices.append((wape(va.llegadas,pred),conf))
    return sorted(choices,key=lambda a:a[0])[0][1],choices


def run_model():
    obs=join_events(load_observed())
    tuning=[]
    params={}
    for with_events,label in [(False,'RF sin festividades'),(True,'RF con festividades')]:
        conf,results=choose_config(obs,with_events)
        params[label]=conf
        for score,candidate in results:
            tuning.append({'modelo':label,'hiperparametros':json.dumps(candidate,sort_keys=True),'WAPE_validacion_2024_pct':round(float(score),3),'seleccionado':candidate==conf})
    save_csv(pd.DataFrame(tuning),RESULTS/'busqueda_hiperparametros_2024.csv')
    summary=[];detail=[]
    for year,months,name in [(2024,12,'Validación 2024'),(2025,12,'Prueba 2025'),(2026,6,'Seguimiento 2026 (ene-jun)')]:
        train=obs[obs.anio<year].copy()
        test=obs[(obs.anio==year)&(obs.mes_num<=months)].copy()
        candidates={
            'Mediana estacional': median_baseline(train,test),
            'Mismo mes año previo': last_year_baseline(train,test),
        }
        for feat,label in [(False,'RF sin festividades'),(True,'RF con festividades')]:
            rf=fit_rf(train,feat,params[label]);candidates[label]=rf_predictions(rf,test,feat)
        for label,pred in candidates.items():
            metric,rows=eval_model(train,test,pred,label,name)
            summary.append(metric);detail.append(rows)
    scores=pd.DataFrame(summary)
    details=pd.concat(detail,ignore_index=True)
    save_csv(scores,RESULTS/'comparacion_modelos_aerocivil.csv')
    save_csv(details,RESULTS/'evaluacion_temporal_detalle.csv')
    # Only data until Jun 2026 are used for final training; no forecast values leak back.
    final=fit_rf(obs,True,params['RF con festividades'])
    MODEL_OUT.mkdir(parents=True,exist_ok=True)
    model_path=MODEL_OUT/'modelo_llegadas_rf_festividades.joblib'
    joblib.dump(final,model_path)
    metadata={
        'modelo':'RandomForestRegressor', 'target':'llegadas de pasajeros aéreos mensuales (NO turistas identificados)',
        'alcance':'7 municipios representados en el registro de Aerocivil',
        'fuente':'datos/aerocivil_choco_raw.csv; agregación municipal con reglas de correspondencia documentadas',
        'entrenado_hasta':'2026-06','n_registros_entrenamiento':int(len(obs)),
        'algoritmo_salida':'np.expm1(pipeline.predict(x)) con truncamiento a cero',
        'feature_columns': BASIC_FEATURES+EVENT_FEATURES,
        'feature_excluidas_por_fuga':['llegadas','salidas','extranjeros'],
        'hiperparametros':params['RF con festividades'],
        'tuning':'búsqueda manual acotada evaluada en 2024 (no se usaron 2025/2026 para elegir parámetros)',
        'version_python':sys.version.split(' ')[0],
        'version_sklearn':__import__('sklearn').__version__,
        'validaciones':['2024','2025','2026 enero-junio'],
        'nota':'No estima todos los turistas del Chocó ni discrimina la motivación del viaje. Algunas fechas de festividades se representan mediante aproximaciones del calendario incorporado.',
        'archivo':str(model_path.relative_to(ROOT)),
    }
    (MODEL_OUT/'metadatos_modelo.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False),encoding='utf-8')
    save_csv(obs,DATA/'dataset_modelo_aerocivil.csv')
    return scores,details,params


def run_forecast():
    from sklearn.pipeline import Pipeline
    meta=json.loads((MODEL_OUT/'metadatos_modelo.json').read_text(encoding='utf-8'))
    model=joblib.load(MODEL_OUT/'modelo_llegadas_rf_festividades.joblib')
    obs=load_observed()
    municipalities=sorted(obs.municipio.unique())
    # Only future months, never existing observed values.
    future=pd.DataFrame([
        {'municipio':mun,'anio':year,'mes_num':month}
        for mun in municipalities for year in (2026,2027)
        for month in range(1,13) if year==2027 or month>=7
    ])
    future=join_events(future)
    pred=rf_predictions(model,future,True)
    future['pred_llegadas']=np.rint(pred).astype(int)
    cuts=thresholds_by_municipio(obs)
    future['demanda_prevista']=[demand_label(m,float(x),cuts) for m,x in zip(future.municipio,pred)]
    coverage=obs.groupby('municipio').agg(meses_observados=('llegadas','size'),meses_2025=('anio',lambda s:int((s==2025).sum())))
    future['meses_historicos']=future.municipio.map(coverage.meses_observados)
    future['cobertura']=future.municipio.map({m:'Cobertura limitada; interpretar con cautela' if row.meses_observados<60 or row.meses_2025<10 else 'Cobertura histórica amplia' for m,row in coverage.iterrows()})
    future['mes']=future.mes_num.map(dict(enumerate(MONTH_NAMES,1)))
    future['modelo']='Random Forest con festividades'
    export_cols=['municipio','anio','mes_num','mes','pred_llegadas','demanda_prevista','cobertura','meses_historicos','dias_fiesta','dias_ballenas','dias_festivo_nac','puentes','semana_santa_dias','modelo']
    save_csv(future[export_cols],MUNI/'pronostico_llegadas_2026H2_2027.csv')
    matrix=future[future.anio==2027].pivot(index='municipio',columns='mes_num',values='demanda_prevista').reset_index()
    save_csv(matrix,MUNI/'matriz_temporadas_2027.csv')
    # Totals only for the listed air-access municipalities; not all Chocó or all tourists.
    agg=(future.groupby(['anio','mes_num','mes'],as_index=False).agg(llegadas_estimadas=('pred_llegadas','sum')))
    history=obs.groupby(['anio','mes_num'],as_index=False).llegadas.sum()
    history=history[(history.anio>=2023)&(history.anio<=2025)]
    x=np.quantile(history.llegadas,[1/3,2/3]); q1,q2=map(float,x)
    agg['demanda_7_aeropuertos']=pd.cut(agg.llegadas_estimadas,bins=[-np.inf,q1,q2,np.inf],labels=['Baja','Media','Alta'],include_lowest=True).astype(str)
    agg['cobertura']='Solo aeropuertos incluidos en los archivos; no turismo total'
    save_csv(agg,RESULTS/'pronostico_mensual_suma_7_municipios.csv')
    summary= {
        'meses_pronosticados':int(agg.shape[0]), 'municipios':municipalities,
        'registros_municipales':len(future),
        'rango':'2026 julio-diciembre y 2027 enero-diciembre',
        'total_2027_estimado_pasajeros_aereos':int(agg[agg.anio==2027].llegadas_estimadas.sum()),
        'interpretacion':'Suma de predicciones de 7 municipios con aeropuertos, NO conteo de turistas.',
    }
    (RESULTS/'resumen_pronostico.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    return future,agg


if __name__=='__main__':
    scores,details,params=run_model()
    future,agg=run_forecast()
    print('EVALUACIONES\n', scores.round(2).to_string(index=False))
    print('\nPronósticos:',len(future),'municipio-meses,',len(agg),'meses departamentales. Modelo:',MODEL_OUT/'modelo_llegadas_rf_festividades.joblib')


def save_model_figures() -> None:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.titlesize':13,'axes.titleweight':'bold'})
    c=['#125f53','#df9164','#386fa0','#8f78ab']
    scores=pd.read_csv(RESULTS/'comparacion_modelos_aerocivil.csv')
    labels=['Mediana estacional','Mismo mes año previo','RF sin festividades','RF con festividades']
    years=list(scores.division.unique())
    fig,ax=plt.subplots(figsize=(12,5))
    for i,method in enumerate(labels):
        y=scores[scores.modelo==method].set_index('division').reindex(years).WAPE_pct
        ax.plot(range(len(years)),y,marker='o',linewidth=2,label=method,color=c[i])
        for j,v in enumerate(y):ax.annotate(f'{v:.1f}%',(j,v),xytext=(0,6),textcoords='offset points',ha='center',fontsize=8)
    ax.set_xticks(range(len(years)),['Validación 2024','Prueba 2025','Seguimiento 2026 H1'])
    ax.set_ylabel('WAPE (%) · menor es mejor');ax.set_title('Evaluación temporal de modelos: error de llegadas aéreas')
    ax.grid(axis='y',alpha=.18);ax.legend(ncol=2,loc='upper center',bbox_to_anchor=(.5,-.12),fontsize=9)
    fig.subplots_adjust(bottom=.3,top=.87)
    fig.savefig(ROOT/'graficos'/'01_comparacion_WAPE.png',bbox_inches='tight');plt.close(fig)
    det=pd.read_csv(RESULTS/'evaluacion_temporal_detalle.csv')
    sub=det[(det.division=='Prueba 2025') & (det.modelo=='RF con festividades')].copy()
    by_month=sub.groupby('mes_num',as_index=False)[['llegadas','pred_llegadas']].sum()
    fig,ax=plt.subplots(figsize=(11.5,4.7))
    ax.plot(by_month.mes_num,by_month.llegadas,color=c[0],label='Observado 2025',marker='o')
    ax.plot(by_month.mes_num,by_month.pred_llegadas,color=c[1],label='RF con festividades',marker='s')
    ax.set_xticks(range(1,13),[m[:3] for m in MONTH_NAMES]);ax.set_ylabel('Pasajeros de llegada')
    ax.set_title('Prueba 2025: llegadas registradas y estimación RF (7 municipios)')
    ax.grid(alpha=.17);ax.legend(loc='upper right')
    fig.tight_layout();fig.savefig(ROOT/'graficos'/'02_2025_observado_vs_predicho.png',bbox_inches='tight');plt.close(fig)
    return None


def save_forecast_figures():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    dep=pd.read_csv(RESULTS/'pronostico_mensual_suma_7_municipios.csv')
    dep['fecha']=pd.to_datetime(dict(year=dep.anio,month=dep.mes_num,day=1))
    obs=load_observed().groupby(['anio','mes_num'],as_index=False).llegadas.sum()
    obs=obs[(obs.anio>=2024)]
    obs['fecha']=pd.to_datetime(dict(year=obs.anio,month=obs.mes_num,day=1))
    fig,ax=plt.subplots(figsize=(12,4.7))
    ax.plot(obs.fecha,obs.llegadas,color='#17615a',marker='o',markersize=3,linewidth=2,label='Observado (aeropuertos incluidos)')
    ax.plot(dep.fecha,dep.llegadas_estimadas,color='#df9164',marker='o',markersize=3,linewidth=2,label='Pronóstico RF (misma cobertura)')
    ax.axvline(pd.Timestamp(2026,6,15),color='#85928f',linestyle='--',alpha=.8)
    ax.set_title('Llegadas aéreas por mes: observado y pronosticado 2026H2–2027')
    ax.set_ylabel('Pasajeros de llegada');ax.grid(alpha=.18);ax.legend(loc='upper left')
    fig.tight_layout();fig.savefig(MUNI/'01_pronostico_aeropuertos_2026_2027.png',bbox_inches='tight');plt.close(fig)

    pred=pd.read_csv(MUNI/'pronostico_llegadas_2026H2_2027.csv')
    m=pred[pred.anio==2027].pivot(index='municipio',columns='mes_num',values='demanda_prevista')
    order=sorted(m.index)
    colors={'Baja':0,'Media':1,'Alta':2,'No estimable':np.nan}
    arr=m.loc[order].apply(lambda col:col.map(colors)).to_numpy(dtype=float)
    fig,ax=plt.subplots(figsize=(12,5.2))
    from matplotlib.colors import ListedColormap
    image=ax.imshow(np.ma.masked_invalid(arr),cmap=ListedColormap(['#b8dfe2','#f7d39b','#e78964']),vmin=-.5,vmax=2.5,aspect='auto')
    ax.set_yticks(range(len(order)),order);ax.set_xticks(range(12),[v[:3] for v in MONTH_NAMES]);ax.set_title('Clasificación mensual prevista para 2027 (umbrales propios por municipio)')
    for i in range(len(order)):
        for j in range(12):
            value=m.loc[order[i],j+1]
            ax.text(j,i, {'Baja':'B','Media':'M','Alta':'A','No estimable':'N/E'}.get(value,'—'),ha='center',va='center',fontsize=8,color='#203b39')
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(facecolor='#b8dfe2',label='Baja'),Patch(facecolor='#f7d39b',label='Media'),Patch(facecolor='#e78964',label='Alta')],loc='upper center',bbox_to_anchor=(.5,-.07),ncol=3)
    fig.subplots_adjust(bottom=.2);fig.savefig(MUNI/'02_matriz_demanda_2027.png',bbox_inches='tight');plt.close(fig)

    focus=['QUIBDO','NUQUI','BAHIA SOLANO','ACANDI']
    fig,ax=plt.subplots(figsize=(12,5))
    for muni,color in zip(focus,['#125f53','#df9164','#386fa0','#8f78ab']):
        d=pred[(pred.anio==2027)&(pred.municipio==muni)].sort_values('mes_num')
        ax.plot(d.mes_num,d.pred_llegadas,linewidth=2,marker='o',markersize=3,label=muni,color=color)
    ax.set_title('Pronóstico de llegadas aéreas mensuales en municipios de mayor flujo (2027)')
    ax.set_ylabel('Llegadas estimadas');ax.set_xticks(range(1,13),[v[:3] for v in MONTH_NAMES]);ax.grid(alpha=.16)
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=4)
    fig.subplots_adjust(bottom=.23)
    fig.savefig(MUNI/'03_pronosticos_municipales_2027.png',bbox_inches='tight');plt.close(fig)
