"""Opcional: genera un Excel legible desde CSV del proyecto; no recalcula el modelo.
Requiere 'artifact-tool' en el entorno (si no está instalado, los CSV son suficientes).
"""
from pathlib import Path
import csv
from artifact_tool import Workbook, SpreadsheetFile
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'resultados_municipales/reporte_general_afluencia_2027.xlsx'
SOURCES={
    'Resumen_2026_2027':ROOT/'resultados/pronostico_mensual_suma_7_municipios.csv',
    'Pronostico_municipal':ROOT/'resultados_municipales/pronostico_llegadas_2026H2_2027.csv',
    'Evaluacion_modelos':ROOT/'resultados/comparacion_modelos_aerocivil.csv',
    'Historico_mensual':ROOT/'resultados/serie_mensual_llegadas_aereas.csv',
    'Diccionario':ROOT/'resultados_choco/diccionario_de_datos.csv',
}
def main():
    wb=Workbook.create()
    for name,path in SOURCES.items():
        rows=list(csv.reader(path.open(encoding='utf-8-sig',newline='')))
        ws=wb.worksheets.add(name)
        if not rows:continue
        endcol=len(rows[0]);nrows=len(rows)
        values=[]
        for i,row in enumerate(rows):
            if i:
                v=[]
                for x in row:
                    try:
                        if x.strip() and x.strip().replace('.','',1).replace('-','',1).isdigit():
                            v.append(float(x) if '.' in x else int(x))
                        else:v.append(x)
                    except Exception:v.append(x)
                values.append(v)
            else:values.append(row)
        ws.get_range_by_indexes(0,0,len(values),endcol).values=values
        hdr=ws.get_range_by_indexes(0,0,1,endcol)
        hdr.format={'fill':'#125F53','font':{'color':'#FFFFFF','bold':True},'row_height':30,'wrap_text':True}
        ws.freeze_panes.freeze_rows(1)
        for j in range(endcol):
            width=30 if name=='Diccionario' else 19
            ws.get_range_by_indexes(0,j,nrows,1).format.column_width=width
        if name=='Diccionario':ws.get_range_by_indexes(0,2,nrows,1).format.column_width=62
    SpreadsheetFile.export_xlsx(wb).save(str(OUT))
    print('Archivo generado:',OUT)
if __name__=='__main__':main()
