"""Diagnóstico complementario reproducible de la Actividad 4: descriptivos, atípicos y gráficas."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'datos'/'dataset_integrado_multifuente.csv'
OUT=ROOT/'resultados_choco'
OUT.mkdir(exist_ok=True)

def run_diagnostico():
    df=pd.read_csv(DATA)
    assert not df.duplicated(['municipio','anio','mes_num']).any(), 'Claves duplicadas'
    base=df[df.anio.between(2020,2025)].copy()  # años completos exclusivamente
    tabla=base.groupby('municipio')['llegadas'].agg(['count','mean','median','std','min','max'])
    tabla.columns=['meses','media','mediana','desviacion','minimo','maximo']
    tabla.round(2).to_csv(OUT/'11_descriptivos_por_municipio.csv',encoding='utf-8-sig')
    q=base.groupby('municipio')['llegadas'].quantile([.25,.75]).unstack()
    q.columns=['q1','q3']; q['iqr']=q.q3-q.q1
    q['limite_inferior']=(q.q1-1.5*q.iqr).clip(lower=0)
    q['limite_superior']=q.q3+1.5*q.iqr
    diag=base.join(q[['limite_inferior','limite_superior']],on='municipio')
    diag['atipico_iqr']=(diag.llegadas < diag.limite_inferior)|(diag.llegadas > diag.limite_superior)
    diag.to_csv(OUT/'12_diagnostico_iqr_municipio.csv',index=False,encoding='utf-8-sig')
    # Univariante 1: histograma de llegadas observadas, variable positiva y asimétrica.
    fig,ax=plt.subplots(figsize=(9,4.4))
    ax.hist(base.llegadas,bins=28,color='#17615a',edgecolor='white')
    ax.set(title='Distribución de llegadas mensuales (2020–2025)',xlabel='Pasajeros por municipio-mes',ylabel='Frecuencia')
    ax.grid(axis='y',alpha=.17);fig.tight_layout()
    fig.savefig(OUT/'11_histograma_llegadas.png',dpi=150);plt.close(fig)
    # Univariante 2: boxplot por municipio para comparar la escala sin eliminar valores.
    fig,ax=plt.subplots(figsize=(10,4.5))
    groups=[base.loc[base.municipio==m,'llegadas'].values for m in sorted(base.municipio.unique())]
    names=sorted(base.municipio.unique())
    ax.boxplot(groups,orientation='horizontal',tick_labels=names,showfliers=True,flierprops={'marker':'.','markersize':4})
    ax.set(title='Dispersión y atípicos por municipio (2020–2025)',xlabel='Llegadas mensuales')
    ax.grid(axis='x',alpha=.18);fig.tight_layout()
    fig.savefig(OUT/'12_boxplot_municipios.png',dpi=150);plt.close(fig)
    # Global: correlaciones descriptivas, solo cruces mensuales donde hay extranjeros.
    numeric=['llegadas','extranjeros_no_residentes_registrados','dias_fiesta','dias_ballenas','puentes']
    x=base[numeric].copy(); corr=x.corr(numeric_only=True)
    corr.to_csv(OUT/'13_correlacion_indicadores.csv',encoding='utf-8-sig')
    fig,ax=plt.subplots(figsize=(8,5.2));im=ax.imshow(corr,cmap='BrBG',vmin=-1,vmax=1)
    short=['Llegadas aéreas','Visitantes extranjeros','Días de fiesta','Días ballenas','Puentes']
    ax.set_xticks(range(5),short,rotation=30,ha='right');ax.set_yticks(range(5),short)
    for i in range(5):
        for j in range(5):
            val=corr.iloc[i,j]
            if pd.notna(val):ax.text(j,i,f'{val:.2f}',ha='center',va='center',fontsize=9,color='black')
    fig.colorbar(im,ax=ax,fraction=.05,pad=.02)
    ax.set_title('Relaciones descriptivas entre indicadores (2020–2025)')
    fig.tight_layout();fig.savefig(OUT/'13_correlacion_multifuente.png',dpi=150);plt.close(fig)
    print('Meses observados 2020-2025:',len(base))
    print('Registros atípicos según IQR municipal:',int(diag.atipico_iqr.sum()))
    print('Registros duplicados municipio-año-mes:',int(df.duplicated(['municipio','anio','mes_num']).sum()))
    print('Cruces con extranjeros:',int(df.extranjeros_no_residentes_registrados.notna().sum()))
    print('Los valores atípicos se conservan; pueden reflejar pandemia, estacionalidad o actividad real.')
    return tabla, diag[diag.atipico_iqr], corr

if __name__ == '__main__':
    run_diagnostico()
