# Integración y trazabilidad de las fuentes de información

## Fuentes utilizadas y finalidad

| Conjunto | Procedencia | Granularidad | Uso |
|---|---|---|---|
| Pasajeros que llegan y salen por vía aérea | Aerocivil; archivos de tráfico aéreo incluidos en `datos/` | Municipio y mes, 2020–junio 2026 | **Variable objetivo**: `llegadas`. |
| Festividades y calendario | Calendarios de festividades incluidos en `datos/` | Municipio y mes, calendario 2020–2027 | Variables conocidas para el pronóstico. |
| Visitantes extranjeros no residentes | Serie estadística de visitantes extranjeros no residentes incluida en `datos/` | Municipio y mes, 2020–2025 | Análisis descriptivo complementario. |
| Detalle por país de residencia | Desagregación por país de la serie de visitantes extranjeros no residentes | País, municipio y mes, 2020–2025 | Conteo de países registrados y comprobación de consistencia. |
| Prestadores, camas y habitaciones RNT | Registro Nacional de Turismo (RNT), resumen municipal de un corte publicado | Municipio, **corte único sin fecha especificada en el archivo** | Contexto de oferta turística, no serie mensual. |

## Cómo se integraron

Se construyó `datos/dataset_integrado_multifuente.csv` a partir de la tabla municipal de Aerocivil, **sin cambiar sus 494 observaciones**. Los calendarios y los registros de extranjeros se emparejaron por las claves `municipio`, `anio` y `mes_num`. El RNT se asoció por municipio, conservando su naturaleza de corte transversal. Para esta asociación se documenta la equivalencia de nombre `BAJO BAUDO (PIZARRO)` → `BAJO BAUDO`.

La base incorporada posee **310 coincidencias con extranjeros**; los demás **184 registros** de Aerocivil no tienen conteo extranjero para la misma combinación municipio–mes. Esos datos **quedan vacíos**, no se convierten en cero. El RNT se vinculó a los siete municipios con cobertura aérea y aparece como información **estática**, repetida solo para permitir el cruce tabular.

El dataset auxiliar de Aerocivil contiene una variable `extranjeros`. Su comparación con la serie de visitantes extranjeros no residentes confirma que las 310 coincidencias corresponden a la misma información disponible: **no constituyen mediciones independientes ni deben contarse dos veces**.

## Qué se puede y qué no se puede concluir

- `llegadas` y `extranjeros_no_residentes_registrados` miden poblaciones y procesos diferentes. **No se suman** para calcular un total de turistas.
- El RNT describe establecimientos/prestadores registrados; **no es un conteo de visitantes**.
- Las fuentes no permiten saber cuántos pasajeros aéreos viajaron exclusivamente por turismo ni separar de manera completa nacionales e internacionales.
- Las series integradas permiten contrastar temporalidad y cobertura, **sin establecer causalidad**.
- Se mantiene como objetivo del modelo `llegadas`. Los valores contemporáneos de extranjeros no se usan como *features* para predecir 2027 porque no se conocen anticipadamente. El RNT tampoco entra al entrenamiento retrospectivo al desconocerse la fecha exacta de su corte; eso evitaría sesgos de información futura.
- 2026 es **parcial** (enero–junio) y no debe compararse como total anual con 2025.

## Comprobaciones de calidad

1. No hay claves municipio–año–mes duplicadas en las tablas de Aerocivil, extranjeros y calendario ni nombres de municipio repetidos en el resumen RNT.
2. Los 2.900 registros desagregados de visitantes extranjeros son coherentes con los **666 conteos municipales mensuales** consolidados para el análisis.
3. La unión preserva las 494 filas de Aerocivil y sus totales de llegadas y salidas.
4. Se distingue entre cero reportado, ausencia de registro y no correspondencia territorial o temporal.
5. Las gráficas usan escalas separadas y rótulos sin superposición.

## Cómo reproducir

Desde la carpeta raíz, ejecutar `python integrar_fuentes.py`. El script regenera los archivos de integración y las visualizaciones en `resultados_choco`. Los tres notebooks documentan el análisis integrado. El modelo predictivo emplea únicamente variables cuya disponibilidad temporal puede justificarse, para evitar filtración de información.
