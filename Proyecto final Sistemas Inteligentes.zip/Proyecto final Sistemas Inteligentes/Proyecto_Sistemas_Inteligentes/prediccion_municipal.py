"""Ejecuta la evaluación de modelos y los pronósticos mensuales a partir de los registros de Aerocivil."""
from modelo_afluencia import run_model, run_forecast

if __name__=='__main__':
    scores,_,_=run_model()
    print(scores.round(2).to_string(index=False))
    muni,department=run_forecast()
    print(f'Pronosticados {len(muni)} meses municipales para 2026H2 y 2027; {len(department)} sumas mensuales.')
