# Estrategia de integración y validación del pronóstico de actividad turística en el Chocó

**Alcance.** El propósito general del EDA es comprender la actividad turística usando diversos indicadores. El objetivo numérico del modelo se limita a los pasajeros que llegan por vía aérea a los aeropuertos cubiertos. Ninguna de las fuentes ofrece, sin más, la cifra total de turistas que entran al departamento.

## 1. Unidades, fuentes y reglas de cruce

| Fuente | Unidad original | Uso correcto | Riesgo que se evita |
|---|---|---|---|
| Aerocivil | Aeropuerto/año/mes y pasajeros | Objetivo `llegadas`; se agrupan códigos de aeropuerto al municipio | No interpretar cada pasajero como turista |
| Extranjeros no residentes | Municipio/año/mes y visitantes registrados | EDA y perfiles históricos sometidos a prueba | No sumar a llegadas aéreas ni utilizar datos futuros |
| Registro Nacional de Turismo (RNT) | Municipio y corte publicado de oferta | Contextualizar prestadores, camas y habitaciones | No atribuir al año 2020 un registro de un corte sin fecha histórica |
| Calendario de festividades | Municipio/año/mes y días/eventos | Predictor conocido de antemano, sujetos a aproximaciones | No afirmar causalidad |

El enlace principal es `municipio` + `anio` + `mes_num`, con nombres normalizados y revisión de claves únicas. El RNT se incorpora por municipio (relación muchos a uno). Aerocivil se conserva como tabla de referencia: su suma y sus **494 filas** no cambian al integrar. Se identifican **310 coincidencias** con extranjeros y **184 ausencias**, mantenidas como valores faltantes. El RNT no es una serie mensual histórica.

Fuentes públicas que documentan el significado de los datos: [Aerocivil, transporte aéreo comercial](https://www.datos.gov.co/d/gb6w-ynu4); [MinCIT, informes turísticos](https://www.mincit.gov.co/estudios-economicos/estadisticas-e-informes/informes-de-turismo); [MinCIT, portal de información turística](https://portucolombia.mincit.gov.co/tematicas/estadisticas-territoriales/estadisticas-territoriales-de-turismo-1). Los archivos específicos utilizados son los incluidos en el proyecto, por lo que los metadatos publicados después de su extracción pueden diferir.

## 2. Decisión sobre la variable objetivo

Se decidió predecir **llegadas aéreas mensuales municipales** (`llegadas`) y calcular sus categorías **Baja**, **Media** y **Alta** según umbrales históricos por municipio. El modelo **no** predice el número absoluto de turistas nacionales e internacionales ni identifica motivos del desplazamiento. Las cifras de extranjeros y el RNT apoyan el contexto interpretativo: mezclarlas sumándolas carecería de validez estadística.

## 3. Evaluación temporal y control de filtraciones

El ajuste de hiperparámetros de Random Forest y la ponderación estacional se realizaron sobre datos anteriores a 2024 con **validación en 2024**. La **prueba 2025** utiliza únicamente períodos anteriores para entrenar y el **seguimiento enero–junio de 2026** excluye esos meses del entrenamiento de cada prueba. El entrenamiento final para pronósticos futuros sí utiliza los datos observados hasta junio de 2026.

Los conteos de extranjeros contemporáneos no son predictores aceptables de un futuro donde no se conocen sus valores. Los perfiles extranjeros se construyeron exclusivamente con el pasado de cada evaluación; el RNT solo se exploró, ya que no dispone de una fecha de corte histórica demostrada.

## 4. Resultados y criterios de elección

| Método | WAPE 2025 | MAE 2025 | Acierto demanda 2025 | WAPE ene–jun 2026 |
|---|---:|---:|---:|---:|
| Mismo mes del año anterior | 10,51 % | 347,10 | 60,98 % | 8,45 % |
| **Estacional suavizado** (90 % año anterior + 10 % segundo anterior) | **10,29 %** | **339,74** | 62,20 % | **8,15 %** |
| Random Forest con festividades | 12,75 % | 421,24 | **64,63 %** | **7,85 %** |

El suavizado mejoró al método del año anterior simple en ambos cortes de prueba, pero **no supera a Random Forest en el primer semestre de 2026 ni en clasificación de 2025**. Es una mejora pequeña en un conjunto de prueba reducido y no demuestra que vaya a mantenerse en nuevos años. No se ha atribuido a las fuentes adicionales una mejora que la evaluación no respalda.

## 5. Pronóstico y lectura prudente

El modelo principal de Machine Learning conservado es Random Forest con festividades. Para los 18 meses comprendidos entre julio de 2026 y diciembre de 2027 se incluye un pronóstico alternativo estacional. En 2027 el pronóstico estacional puede utilizar valores que él mismo estimó para el año anterior: **su carácter recursivo se indica por registro**. El resultado principal no se reemplazó automáticamente por el enfoque con menor WAPE de 2025.

Las comparaciones numéricas incluyen exclusivamente los **siete municipios con registro aéreo**; no representan todos los accesos al departamento. En 2026 solo existen registros observados de enero a junio. Juradó tiene **30 meses** y una cobertura significativamente menor que los demás; sus predicciones deben interpretarse con cautela.

## 6. Evidencias y reproducción

Las tablas de cruce están en `datos/dataset_integrado_multifuente.csv` y `resultados_choco/cobertura_integracion_fuentes.csv`. El análisis empírico de RNT/extranjeros está en `resultados/evaluacion_integrada_comparacion.csv`, y el experimento estacional en `resultados/evaluacion_referencia_suavizada.csv`. Los escenarios municipales están en `resultados_municipales/pronostico_comparativo_dos_modelos.csv`.

Los comandos para obtener los resultados son:

```bash
python integrar_fuentes.py
python modelo_afluencia.py
python evaluar_variables_integradas.py
python evaluar_enfoque_estacional.py
```

Para publicación académica, los resultados deben acompañarse siempre de la definición de la unidad estadística, de la cobertura territorial y de las limitaciones de cada fuente. El modelo incluido en este repositorio no actualiza automáticamente ninguna instancia de aplicación web: su despliegue requiere una publicación independiente.
