"""EDA reproducible de la actividad turística, mediante indicadores de Aerocivil, visitantes extranjeros, RNT y festividades."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from modelo_afluencia import ROOT,DATA,RESULTS,MUNI,load_observed,save_csv,MONTH_NAMES

CHART=ROOT/'resultados_choco'
CHART.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.titlesize':14,'axes.titleweight':'bold','figure.dpi':120})
BLUE='#17615a';ORANGE='#df9361';DARK='#203b39'


def run_eda():
    raw=pd.read_csv(DATA/'aerocivil_choco_raw.csv')
    muni=load_observed()
    save_csv(muni,DATA/'aerocivil_municipal_recalculado.csv')
    assert len(raw)==606 and len(muni)==494, 'Cambió el dataset esperado; actualiza el resumen documentado.'
    annual=muni.groupby('anio',as_index=False).agg(llegadas=('llegadas','sum'),salidas=('salidas','sum'),registros=('llegadas','size'))
    annual['periodo']=annual.anio.astype(str)
    annual.loc[annual.anio==2026,'periodo']='2026 (ene-jun)'
    save_csv(annual,CHART/'llegadas_aereas_por_anio.csv')
    top=(muni[muni.anio==2025].groupby('municipio',as_index=False).agg(llegadas=('llegadas','sum'),meses_reportados=('mes_num','size')).sort_values('llegadas',ascending=False))
    save_csv(top,CHART/'llegadas_por_municipio_2025.csv')
    monthly=muni.groupby(['anio','mes_num'],as_index=False).agg(llegadas=('llegadas','sum'),municipios_reportados=('municipio','nunique'))
    monthly['fecha']=pd.to_datetime(dict(year=monthly.anio,month=monthly.mes_num,day=1))
    save_csv(monthly,RESULTS/'serie_mensual_llegadas_aereas.csv')
    allmonths=pd.MultiIndex.from_product([sorted(muni.municipio.unique()),pd.period_range('2020-01','2026-06',freq='M')],names=['municipio','periodo'])
    observed_idx=pd.MultiIndex.from_frame(pd.DataFrame({'municipio':muni.municipio,'periodo':pd.PeriodIndex(muni.fecha,freq='M')}))
    missing=allmonths.difference(observed_idx)
    absent=pd.DataFrame([{'municipio':m,'anio':p.year,'mes_num':p.month} for m,p in missing])
    save_csv(absent,CHART/'meses_sin_reporte_no_equivalen_a_cero.csv')
    coverage=muni.groupby('municipio').agg(n_meses_observados=('llegadas','size'),total_llegadas=('llegadas','sum'),llegadas_min=('llegadas','min'),llegadas_max=('llegadas','max')).reset_index()
    coverage['meses_sin_registro_2020_2026H1']=78-coverage.n_meses_observados
    save_csv(coverage,CHART/'cobertura_municipal.csv')
    dictionary=pd.DataFrame([
     ('anio','entero','Año de la operación aérea; 2026 solo enero-junio'),
     ('mes','entero 1-12','Mes reportado para cada aeropuerto en el original'),
     ('aeropuerto','texto','Código aeroportuario; códigos asignados a municipio'),
     ('llegadas','entero >=0','Pasajeros de llegada por aeropuerto-mes; variable objetivo'),
     ('salidas','entero >=0','Pasajeros de salida; no se usa para predecir llegadas futuras'),
     ('municipio','texto','Municipio asociado al aeropuerto (agrupación por mes)'),
     ('mes_num','entero 1-12','Mes tras agrupar la fuente en municipio-mes'),
     ('fecha','fecha AAAA-MM-01','Inicio del mes; construido de año y mes'),
     ('dias_fiesta','entero >=0','Número de días de festividad local según el calendario del estudio'),
     ('dias_ballenas','entero >=0','Días de temporada de ballenas según el calendario del estudio'),
     ('dias_festivo_nac','entero >=0','Días festivos nacionales según calendario facilitado'),
     ('puentes','entero >=0','Puentes festivos según calendario facilitado'),
     ('semana_santa_dias','entero >=0','Días de Semana Santa según calendario facilitado'),
     ],columns=['variable','tipo','significado'])
    save_csv(dictionary,CHART/'diccionario_de_datos.csv')
    
    fig,ax=plt.subplots(figsize=(11,5.4))
    colors=[BLUE]*len(annual);colors[-1]=ORANGE
    bar=ax.bar(annual.periodo,annual.llegadas,color=colors)
    ax.bar_label(bar,labels=[f'{i:,.0f}'.replace(',','.') for i in annual.llegadas],padding=3,fontsize=9)
    ax.set_title('Llegadas de pasajeros aéreos registradas por año')
    ax.set_ylabel('Pasajeros');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    ax.tick_params(axis='x',labelrotation=12)
    ax.text(.02,-.17,'Nota: 2026 abarca solo enero-junio; no es comparable con años completos.',transform=ax.transAxes,fontsize=9,color=DARK)
    fig.subplots_adjust(bottom=.26);fig.savefig(CHART/'01_llegadas_anuales.png',bbox_inches='tight');plt.close(fig)

    fig,ax=plt.subplots(figsize=(12,4.8))
    ax.plot(monthly.fecha,monthly.llegadas,color=BLUE,linewidth=2,marker='o',markersize=2.5)
    ax.set_title('Serie mensual de llegadas aéreas a los aeropuertos incluidos')
    ax.set_ylabel('Pasajeros/mes');ax.grid(alpha=.18)
    ax.text(.01,-.15,'Meses sin reporte en algún aeropuerto no se completan automáticamente con cero.',transform=ax.transAxes,fontsize=9)
    fig.subplots_adjust(bottom=.24);fig.savefig(CHART/'02_serie_mensual.png',bbox_inches='tight');plt.close(fig)

    fig,ax=plt.subplots(figsize=(11,5))
    rev=top.sort_values('llegadas')
    bars=ax.barh(rev.municipio,rev.llegadas,color=BLUE)
    ax.bar_label(bars,labels=[f'{x:,.0f}'.replace(',','.') for x in rev.llegadas],padding=4,fontsize=9)
    ax.set_xlim(0,top.llegadas.max()*1.19)
    ax.set_title('Llegadas aéreas por municipio en 2025')
    ax.set_xlabel('Pasajeros');ax.grid(axis='x',alpha=.13);ax.set_axisbelow(True)
    fig.tight_layout();fig.savefig(CHART/'03_municipios_2025.png',bbox_inches='tight');plt.close(fig)

    mat=(muni[muni.anio==2025].pivot(index='municipio',columns='mes_num',values='llegadas')
         .reindex(sorted(muni.municipio.unique())))
    fig,ax=plt.subplots(figsize=(12,5))
    normalized=np.log1p(mat.astype(float).values)
    image=ax.imshow(np.ma.masked_invalid(normalized),cmap='YlGnBu',aspect='auto')
    ax.set_xticks(np.arange(12),[m[:3] for m in MONTH_NAMES]);ax.set_yticks(np.arange(len(mat)),list(mat.index))
    ax.set_title('Llegadas aéreas en 2025 · escala logarítmica de color')
    cbar=fig.colorbar(image,ax=ax,pad=.01);cbar.set_label('log(1 + pasajeros)')
    ax.set_xlabel('Mes')
    fig.tight_layout();fig.savefig(CHART/'04_matriz_llegadas_2025.png',bbox_inches='tight');plt.close(fig)

    # Estacionalidad descriptiva reciente, sin interpretar faltantes como 0.
    med=(monthly[monthly.anio.between(2021,2025)].groupby('mes_num').llegadas.median().reindex(range(1,13)))
    fig,ax=plt.subplots(figsize=(11,4.8))
    bars=ax.bar(np.arange(1,13),med,color=[ORANGE if x>=med.quantile(2/3) else BLUE for x in med])
    ax.set_xticks(np.arange(1,13),[v[:3] for v in MONTH_NAMES]);ax.set_ylabel('Mediana de pasajeros reportados')
    ax.set_title('Estacionalidad descriptiva de llegadas aéreas · 2021–2025')
    ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    fig.tight_layout();fig.savefig(CHART/'05_estacionalidad_mensual.png',bbox_inches='tight');plt.close(fig)

    # Síntesis redactada a partir de los resultados calculados; sin alterar el procesamiento.
    notes=[
        'HALLAZGOS DEL EDA MULTIFUENTE DE LA ACTIVIDAD TURÍSTICA DEL CHOCÓ',
        '',
        'Alcance del estudio',
        'El EDA se plantea para comprender la actividad turística del Chocó mediante Aerocivil, registros de visitantes extranjeros no residentes, oferta del RNT y calendarios. Este módulo calcula específicamente las estadísticas de movilidad aérea; las demás dimensiones se integran y examinan desde el notebook y el módulo integrar_fuentes.py. Las llegadas aéreas no representan por sí solas la totalidad de turistas.',
        f'El archivo original contiene {len(raw)} observaciones aeropuerto-mes. Después de agrupar los códigos de aeropuertos por municipio se obtuvieron {len(muni)} observaciones municipio-mes de {muni.municipio.nunique()} municipios y {raw.aeropuerto.nunique()} aeropuertos, para el período {muni.fecha.min():%Y-%m} a {muni.fecha.max():%Y-%m}.',
        '',
        'Evolución y distribución territorial',
        f'En 2025 se contabilizaron {int(annual.loc[annual.anio==2025,"llegadas"].iloc[0]):,} llegadas en los aeropuertos incluidos. Entre enero y junio de 2026 se registraron {int(annual.loc[annual.anio==2026,"llegadas"].iloc[0]):,} llegadas, cifra que corresponde a un semestre y no a un año completo.',
        'El movimiento aéreo no se distribuye de manera uniforme entre municipios. Para interpretar las diferencias, se elaboraron comparaciones anuales, una serie mensual, un ranking municipal de 2025 y una matriz de estacionalidad.',
        '',
        'Calidad de los registros',
        f'Se identificaron {len(absent)} combinaciones municipio-mes sin información entre enero de 2020 y junio de 2026. Estas ausencias no se sustituyeron por ceros, ya que no reportar un mes no significa que no hayan llegado pasajeros.',
        'Los códigos ACD y CPB se agruparon en Acandí, y BSC y CPC en Bahía Solano. Los visitantes extranjeros y la oferta RNT se integran para análisis descriptivo en el módulo integrar_fuentes.py, sin sumar cantidades que miden fenómenos diferentes.',
        '',
        'Aporte al modelo y limitaciones',
        'La variable que se busca predecir es el número de llegadas de pasajeros por municipio y mes. Posteriormente, cada estimación se interpreta como demanda baja, media o alta con base en el comportamiento histórico municipal.',
        'La fuente no identifica el motivo de viaje, no distingue turistas únicos de otros pasajeros y no incluye entradas por vías terrestres o fluviales. Por ello, los resultados no equivalen a una medición de todos los turistas del Chocó.',
    ]
    (RESULTS/'hallazgos_eda.txt').write_text('\n'.join(notes)+'\n',encoding='utf-8')
    return annual,top,monthly,coverage,absent

if __name__=='__main__':
    annual,top,monthly,coverage,absent=run_eda()
    print('EDA ejecutado. Series anuales:\n',annual.to_string(index=False))
    print('\nMunicipios 2025:\n',top.to_string(index=False))
    print('\nMeses sin reporte:',len(absent))
