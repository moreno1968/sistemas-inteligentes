"""Evaluación controlada del aporte predictivo de fuentes integradas.

Afluencia = llegadas de pasajeros aéreos, no total de turistas.
Para cada corte, el perfil de extranjeros utiliza únicamente datos de años
anteriores al período evaluado. RNT es un corte estático de fecha no indicada:
los escenarios RNT son EXPLORATORIOS, no validación histórica estricta.
"""
from __future__ import annotations
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_absolute_error

import modelo_afluencia as modelo

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'datos'
OUT = ROOT / 'resultados'
OUT.mkdir(exist_ok=True)

RNT_FEATURES = ['rnt_prestadores','rnt_camas','rnt_habitaciones']
EXT_FEATURES = ['ext_municipal_log','ext_estacional_log','ext_conteos_municipal','ext_conteos_estacional']
VARIANTS = {
    'RF calendario': {'eventos':False,'rnt':False,'perfil':False},
    'RF + festividades': {'eventos':True,'rnt':False,'perfil':False},
    'RF + festividades + RNT*': {'eventos':True,'rnt':True,'perfil':False},
    'RF + festividades + perfil extranjeros': {'eventos':True,'rnt':False,'perfil':True},
    'RF + festividades + RNT* + perfil extranjeros': {'eventos':True,'rnt':True,'perfil':True},
}


def foreign_profile(asof_year: int) -> dict:
    """Medias mensuales históricas SOLO hasta asof_year; no meses objetivo."""
    foreigners = pd.read_csv(DATA / 'visitantes_extranjeros_municipal_mensual.csv')
    foreigners = foreigners[foreigners.anio <= asof_year].copy()
    if foreigners.empty:
        raise ValueError('No hay historia extranjera disponible antes del corte de entrenamiento.')
    municipality = foreigners.groupby('municipio').visitantes.agg(['mean','count'])
    month = foreigners.groupby(['municipio','mes_num']).visitantes.agg(['mean','count'])
    return {'municipal':municipality, 'mensual':month,
            'global':float(foreigners.visitantes.mean()), 'corte_anio':asof_year}


def features(frame: pd.DataFrame, variant: dict, profile: dict | None) -> pd.DataFrame:
    X = modelo.add_features(frame,include_events=variant['eventos']).copy()
    if variant['rnt']:
        for k in RNT_FEATURES:
            if frame[k].isna().any():raise ValueError('El RNT carece de datos: no se imputan ceros.')
            X[k] = np.log1p(frame[k].to_numpy(float))
    if variant['perfil']:
        if profile is None: raise ValueError('Falta perfil histórico de extranjeros')
        mu,mo,base = profile['municipal'],profile['mensual'],profile['global']
        mvals,mmvals,counts,mcounts=[],[],[],[]
        for r in frame.itertuples():
            if r.municipio in mu.index:
                gm=float(mu.loc[r.municipio,'mean']);cn=int(mu.loc[r.municipio,'count'])
            else:gm=base;cn=0
            if (r.municipio,r.mes_num) in mo.index:
                gmo=float(mo.loc[(r.municipio,r.mes_num),'mean']);cm=int(mo.loc[(r.municipio,r.mes_num),'count'])
            else:gmo=gm;cm=0
            mvals.append(np.log1p(max(gm,0)))
            mmvals.append(np.log1p(max(gmo,0)))
            counts.append(cn);mcounts.append(cm)
        X['ext_municipal_log']=mvals
        X['ext_estacional_log']=mmvals
        X['ext_conteos_municipal']=counts
        X['ext_conteos_estacional']=mcounts
    return X


def fit_variant(train:pd.DataFrame,v:dict,config:dict,profile:dict|None):
    x=features(train,v,profile)
    nums=[c for c in x if c not in ('municipio','mes_num')]
    prep=ColumnTransformer([
        ('municipio',OneHotEncoder(handle_unknown='ignore'),['municipio']),
        ('mes',OneHotEncoder(handle_unknown='ignore'),['mes_num']),
        ('numericas','passthrough',nums),
    ])
    model=Pipeline([('preprocesamiento',prep),('random_forest',RandomForestRegressor(
        **config,random_state=42,n_jobs=-1))])
    model.fit(x,np.log1p(train.llegadas))
    return model


def predict_variant(fitted,test,v,profile):
    return np.maximum(0,np.expm1(fitted.predict(features(test,v,profile))))


def get_data():
    base=modelo.join_events(modelo.load_observed())
    integrated=pd.read_csv(DATA / 'dataset_integrado_multifuente.csv')
    key=['municipio','anio','mes_num']
    cols=key+RNT_FEATURES
    merged=base.merge(integrated[cols],on=key,how='left',validate='one_to_one',indicator=True)
    if len(merged)!=len(base) or merged['_merge'].ne('both').any():
        raise ValueError('La integración modificó la cobertura de Aerocivil.')
    merged=merged.drop(columns=['_merge'])
    return merged


def run():
    dataset=get_data()
    tuner=[];selected={}
    train=dataset[dataset.anio<=2023].copy()
    val=dataset[dataset.anio==2024].copy()
    ext_profile=foreign_profile(2023)
    for label,v in VARIANTS.items():
        tries=[]
        for cfg in modelo.CONFIGS:
            fitted=fit_variant(train,v,cfg,ext_profile if v['perfil'] else None)
            pred=predict_variant(fitted,val,v,ext_profile if v['perfil'] else None)
            error=float(modelo.wape(val.llegadas,pred))
            tries.append((error,cfg))
        score,cfg=min(tries,key=lambda z:z[0]); selected[label]=cfg
        for error,c in tries:
            tuner.append({'modelo':label,'hiperparametros':json.dumps(c,sort_keys=True),
                          'WAPE_validacion_2024_pct':round(error,4), 'seleccionado':c==cfg})
        print('2024 tuning:',label,'WAPE',round(score,3),'params',cfg,flush=True)
    pd.DataFrame(tuner).to_csv(OUT/'evaluacion_integrada_tuning_2024.csv',index=False,encoding='utf-8-sig')
    summaries=[];details=[];per_municipality=[]
    for test_year,test_limit,name in [(2025,12,'Prueba 2025'),(2026,6,'Seguimiento ene-jun 2026')]:
        tr=dataset[dataset.anio<test_year].copy()
        te=dataset[(dataset.anio==test_year)&(dataset.mes_num<=test_limit)].copy()
        if len(te)==0:raise ValueError('Prueba sin registros')
        profile=foreign_profile(test_year-1)
        candidates={
            'Mediana estacional': modelo.median_baseline(tr,te),
            'Mismo mes año previo': modelo.last_year_baseline(tr,te)
        }
        for label,v in VARIANTS.items():
            mdl=fit_variant(tr,v,selected[label],profile if v['perfil'] else None)
            candidates[label]=predict_variant(mdl,te,v,profile if v['perfil'] else None)
        for label,pred in candidates.items():
            metric,items=modelo.eval_model(tr,te,pred,label,name)
            metric['fuentes_utilizadas'] = ('Aerocivil; calendario; RNT (corte estático no fechado); extranjeros (perfil pasado)' if label.endswith('RNT* + perfil extranjeros') else
                                            'Aerocivil; calendario; extranjeros (perfil pasado)' if 'perfil extranjeros' in label else
                                            'Aerocivil; calendario; RNT (corte estático no fechado)' if 'RNT*' in label else
                                            'Aerocivil; calendario' if 'festividades' in label else 'Aerocivil')
            metric['advertencia_rnt'] = '*' in label
            summaries.append(metric); details.append(items)
            items['error_abs']=(items['llegadas']-items['pred_llegadas']).abs()
            for muni,g in items.groupby('municipio'):
                per_municipality.append({'division':name,'modelo':label,'municipio':muni,'n':len(g),
                                          'WAPE_pct':float(modelo.wape(g.llegadas,g.pred_llegadas)),
                                          'MAE':float(g.error_abs.mean())})
        print('Evaluado',name,'n',len(te),flush=True)
    scores=pd.DataFrame(summaries)
    scores.to_csv(OUT/'evaluacion_integrada_comparacion.csv',index=False,encoding='utf-8-sig')
    pd.concat(details,ignore_index=True).to_csv(OUT/'evaluacion_integrada_detalle.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(per_municipality).to_csv(OUT/'evaluacion_integrada_municipios.csv',index=False,encoding='utf-8-sig')
    print('\nRESULTADOS\n',scores[['division','modelo','n','MAE','WAPE_pct','acierto_demanda_pct','n_clasificables']].round(2).to_string(index=False))
    return scores

if __name__=='__main__':run()
